# Django Code of Conduct

See https://www.djangoproject.com/conduct/.
